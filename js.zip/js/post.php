<?php

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $formcontent="From: $name \n Email: $email \n Message: $message";
    $recipient = "willamscott01@gmail.com";
    $subject = "Website Form Submission";
    $mailheader = "From: $email \r\n";
    mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
    echo "Thank You!";
}

?>
<form method="post">
    <input type="text" name="name" placeholder="Name">
    <input type="text" name="email" placeholder="Email">
    <textarea name="message" placeholder="Message"></textarea>
    <input type="submit" name="submit" value="Submit">
</form>